import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import AuthorWebsite from './AuthorWebsite';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthorWebsite />
  </React.StrictMode>
);
