import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const categorizedBooks = {
  Journals: [
    {
      title: "Before the Breakthrough",
      subtitle: "Companion Journal",
      image: "/images/before-the-breakthrough.jpg",
    },
    {
      title: "Before the Breakthrough Companion Journal",
      subtitle: "A Guided Journal for the Sacred Middle of Healing",
      image: "/images/before-the-breakthrough-journal.jpg",
    },
    {
      title: "From Surviving to Soaring Journal",
      subtitle: "",
      image: "/images/from-surviving-to-soaring-journal.jpg",
    }
  ],
  Healing: [
    {
      title: "Still Worthy",
      subtitle: "Healing Adult Wounds That Still Hurt",
      image: "/images/still-worthy.jpg",
    },
    {
      title: "Loving Them, Supporting You",
      subtitle: "For the Ones Who Stay, Love, and Support Through Mental Illness",
      image: "/images/loving-them-supporting-you.jpg",
    },
    {
      title: "You Are Not Alone",
      subtitle: "Letters of Light for the Dark Days",
      image: "/images/you-are-not-alone.jpg",
    },
    {
      title: "From Surviving to Soaring",
      subtitle: "A Gentle Guide to Healing Childhood Wounds",
      image: "/images/from-surviving-to-soaring.jpg",
    },
    {
      title: "The Strong One Is Tired",
      subtitle: "How the Overburdened Can Overcome",
      image: "/images/the-strong-one-is-tired.jpg",
    }
  ],
  Inspirational: [
    {
      title: "Love Letters from God",
      subtitle: "A Journey of Encouragement, Healing, and Truth",
      image: "/images/love-letters-from-god.jpg",
    },
    {
      title: "Worthy. Worth It. Beloved. Crowned in Love",
      subtitle: "A Love Letter to Women",
      image: "/images/worthy-worth-it.jpg",
    }
  ],
  Children: [
    {
      title: "Queens of the Rising Light",
      subtitle: "",
      image: "/images/queens-of-the-rising-light.jpg",
    }
  ]
};

export default function AuthorWebsite() {
  return (
    <div className="bg-blue-50 text-gray-900 min-h-screen p-6 max-w-7xl mx-auto">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-rose-700">Jomesa D. Boone</h1>
        <p className="mt-2 text-lg text-blue-600">
          Uplifting, Healing & Empowering Reads for Every Journey
        </p>
        <nav className="mt-4 flex justify-center gap-6 text-blue-700">
          <a href="#journals" className="hover:underline">Journals</a>
          <a href="#healing" className="hover:underline">Healing</a>
          <a href="#inspirational" className="hover:underline">Inspirational</a>
          <a href="#children" className="hover:underline">Children</a>
        </nav>
      </header>

      {Object.entries(categorizedBooks).map(([category, books], i) => (
        <section key={i} id={category.toLowerCase()} className="mb-12">
          <h2 className="text-2xl font-bold text-center mb-6 text-rose-700">{category}</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {books.map((book, index) => (
              <Card key={index} className="rounded-2xl shadow-md bg-white">
                <img
                  src={book.image}
                  alt={book.title}
                  className="rounded-t-2xl object-cover h-64 w-full"
                />
                <CardContent className="p-4">
                  <h3 className="text-xl font-semibold mb-1">{book.title}</h3>
                  <p className="text-sm text-blue-700 mb-3">{book.subtitle}</p>
                  <Button className="w-full bg-rose-700 hover:bg-rose-800 text-white">
                    Get Your Copy
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      ))}

      <section className="mt-16 text-center">
        <h2 className="text-2xl font-bold mb-2 text-rose-700">Stay Connected</h2>
        <p className="mb-4 text-blue-600">
          Join Jomesa’s mailing list for book updates, inspiration, and exclusive content.
        </p>
        <div className="max-w-md mx-auto flex gap-2">
          <Input placeholder="Enter your email" className="bg-white" />
          <Button className="bg-rose-700 hover:bg-rose-800 text-white">Subscribe</Button>
        </div>
      </section>

      <footer className="mt-16 text-center text-sm text-blue-500">
        <p>&copy; {new Date().getFullYear()} Jomesa D. Boone. All rights reserved.</p>
        <div className="flex justify-center mt-2 gap-4">
          <a href="#" className="hover:underline">Instagram</a>
          <a href="#" className="hover:underline">Facebook</a>
          <a href="#" className="hover:underline">Contact</a>
        </div>
      </footer>
    </div>
  );
}
